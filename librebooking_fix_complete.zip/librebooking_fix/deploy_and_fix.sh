#!/usr/bin/env bash
# =============================================================
#  deploy_and_fix.sh
#  Исправляет ВСЕ найденные ошибки LibreBooking JINR.
#  Запускать из папки со скриптом: sudo bash deploy_and_fix.sh
# =============================================================
set -euo pipefail

LB="/var/www/html/librebooking"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

RED='\033[0;31m'; YEL='\033[1;33m'; GRN='\033[0;32m'; BLU='\033[0;34m'; NC='\033[0m'
err()  { echo -e "${RED}[ОШИБКА]${NC} $*"; }
warn() { echo -e "${YEL}[ВНИМАНИЕ]${NC} $*"; }
ok()   { echo -e "${GRN}[OK]${NC} $*"; }
info() { echo -e "${BLU}[INFO]${NC} $*"; }

echo ""
echo "========================================================"
echo " LibreBooking JINR — диагностика и исправление"
echo "========================================================"
echo ""

# ── Проверка директории ──────────────────────────────────────
if [[ ! -d "$LB" ]]; then
    err "Директория LibreBooking не найдена: $LB"
    echo "Измените переменную LB в начале скрипта на правильный путь."
    exit 1
fi
ok "LibreBooking найден: $LB"

STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$LB/_fix_deploy_$STAMP"
mkdir -p "$BACKUP_DIR"

# ══════════════════════════════════════════════════════════════
# БЛОК 1: Очистка stale-компайлов Smarty
# ══════════════════════════════════════════════════════════════
echo ""
echo "── 1. Очистка кеша Smarty (tpl_c) ──"
TPL_C="$LB/tpl_c"
if [[ -d "$TPL_C" ]]; then
    COUNT=$(find "$TPL_C" -type f | wc -l)
    find "$TPL_C" -type f -delete 2>/dev/null || true
    ok "Удалено скомпилированных шаблонов: $COUNT"
    info "Smarty скомпилирует их заново при первом запросе"
    info "(Это НУЖНО при cache.templates=true — иначе старые шаблоны не обновляются)"
else
    warn "Директория tpl_c не найдена: $TPL_C"
fi

# ══════════════════════════════════════════════════════════════
# БЛОК 2: Очистка jinr-файлов
# ══════════════════════════════════════════════════════════════
echo ""
echo "── 2. Очистка артефактов ChatGPT-скрипта ──"

JINR_CSS="$LB/Web/css/jinr_header_exact.css"
JINR_JS="$LB/Web/scripts/jinr_header_exact.js"

for f in "$JINR_CSS" "$JINR_JS"; do
    if [[ -f "$f" ]]; then
        cp "$f" "$BACKUP_DIR/$(basename "$f").bak"
        rm -f "$f"
        ok "Удалён устаревший файл: $f"
    fi
done

# Убедиться что в globalheader.tpl нет jinr-ссылок
GLOBALHEADER="$LB/tpl/globalheader.tpl"
if [[ -f "$GLOBALHEADER" ]]; then
    if grep -q "jinr_header_exact" "$GLOBALHEADER"; then
        cp "$GLOBALHEADER" "$BACKUP_DIR/globalheader.tpl.bak"
        # Удаляем строки с jinr_header_exact
        sed -i '/jinr_header_exact/d' "$GLOBALHEADER"
        warn "globalheader.tpl содержал jinr-ссылки — УДАЛЕНЫ"
    else
        ok "globalheader.tpl чист (jinr-ссылок нет)"
    fi
fi

# ══════════════════════════════════════════════════════════════
# БЛОК 3: Деплой исправленных CSS-файлов
# ══════════════════════════════════════════════════════════════
echo ""
echo "── 3. Деплой исправленных CSS-файлов ──"

for cssfile in "Web/css/schedule.css" "Web/css/calendar-modernized.css"; do
    src="$SCRIPT_DIR/$cssfile"
    dst="$LB/$cssfile"
    if [[ -f "$src" ]]; then
        if [[ -f "$dst" ]]; then
            cp "$dst" "$BACKUP_DIR/$(basename "$dst").bak"
        fi
        cp "$src" "$dst"
        chown www-data:www-data "$dst" 2>/dev/null || true
        chmod 644 "$dst"
        ok "Обновлён: $dst ($(wc -l < "$dst") строк)"
    else
        warn "Файл не найден в пакете: $src"
    fi
done

# ══════════════════════════════════════════════════════════════
# БЛОК 4: Диагностика подключения к БД
# ══════════════════════════════════════════════════════════════
echo ""
echo "── 4. Диагностика подключения к БД ──"

CONFIG="$LB/config/config.php"
if [[ ! -f "$CONFIG" ]]; then
    err "config.php не найден!"
else
    DB_HOST=$(php -r "
        \$c = include '$CONFIG';
        echo \$c['settings']['database']['hostspec'] ?? 'NOT_SET';
    " 2>/dev/null)
    DB_NAME=$(php -r "
        \$c = include '$CONFIG';
        echo \$c['settings']['database']['name'] ?? 'NOT_SET';
    " 2>/dev/null)
    DB_USER=$(php -r "
        \$c = include '$CONFIG';
        echo \$c['settings']['database']['user'] ?? 'NOT_SET';
    " 2>/dev/null)
    DB_PASS=$(php -r "
        \$c = include '$CONFIG';
        echo \$c['settings']['database']['password'] ?? 'NOT_SET';
    " 2>/dev/null)

    info "DB host: $DB_HOST  | DB: $DB_NAME  | User: $DB_USER"

    # Проверяем подключение
    DB_CHECK=$(php -r "
        \$conn = @mysqli_connect('$DB_HOST', '$DB_USER', '$DB_PASS', '$DB_NAME');
        if (\$conn) {
            \$r = @mysqli_query(\$conn, 'SELECT version_number FROM dbversion ORDER BY version_date DESC LIMIT 1');
            if (\$r && \$row = mysqli_fetch_assoc(\$r)) {
                echo 'OK schema=' . \$row['version_number'];
            } else {
                echo 'OK_NO_SCHEMA';
            }
            mysqli_close(\$conn);
        } else {
            echo 'FAIL:' . mysqli_connect_error();
        }
    " 2>/dev/null)

    if [[ "$DB_CHECK" == OK* ]]; then
        ok "База данных: $DB_CHECK"
    else
        err "База данных: $DB_CHECK"
        echo ""
        warn "ПРИЧИНА 'Неизвестной ошибки' на странице входа:"
        warn "LibreBooking не может подключиться к БД или выполнить запрос."
        warn "Проверьте настройки в $CONFIG"
        echo ""
    fi
fi

# ══════════════════════════════════════════════════════════════
# БЛОК 5: Права доступа
# ══════════════════════════════════════════════════════════════
echo ""
echo "── 5. Права доступа ──"

for dir in tpl_c cache uploads Web/uploads/images Web/uploads/tos; do
    fullpath="$LB/$dir"
    if [[ -d "$fullpath" ]]; then
        chown -R www-data:www-data "$fullpath" 2>/dev/null || true
        chmod -R 755 "$fullpath" 2>/dev/null || true
        ok "Права установлены: $fullpath"
    else
        # Создаём если нужно
        if [[ "$dir" == "tpl_c" || "$dir" == "cache" ]]; then
            mkdir -p "$fullpath"
            chown www-data:www-data "$fullpath"
            chmod 755 "$fullpath"
            ok "Создан и настроен: $fullpath"
        else
            warn "Директория не существует (необязательная): $fullpath"
        fi
    fi
done

chown -R www-data:www-data "$LB/Web/css" "$LB/Web/scripts" 2>/dev/null || true

# ══════════════════════════════════════════════════════════════
# БЛОК 6: Финал
# ══════════════════════════════════════════════════════════════
echo ""
echo "========================================================"
echo " Итог"
echo "========================================================"
echo ""
echo "Что исправлено:"
echo "  1. Очищен кеш Smarty (tpl_c) — шаблоны скомпилируются заново"
echo "  2. Удалены файлы jinr_header_exact (если остались)"
echo "  3. Очищены jinr-ссылки из globalheader.tpl (если остались)"
echo "  4. Развёрнуты исправленные CSS: schedule.css, calendar-modernized.css"
echo "  5. Установлены права www-data на tpl_c, cache, uploads"
echo ""
echo "Бэкап изменённых файлов: $BACKUP_DIR"
echo ""
echo -e "${GRN}Обнови страницу браузером: Ctrl+F5${NC}"
echo ""
echo "Если ошибка сохраняется — проверь логи:"
echo "  sudo tail -100 /var/log/apache2/error.log | grep -i librebooking"
echo "  sudo tail -100 /var/log/librebooking/log"
echo ""
